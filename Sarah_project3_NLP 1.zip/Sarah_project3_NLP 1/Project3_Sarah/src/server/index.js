import path from 'path';
import express from 'express';
import bodyParser from 'body-parser';
import fetch from 'node-fetch';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('dist'));

const apiKey = process.env.API_KEY;
const apiEndpoint = 'https://api.meaningcloud.com/sentiment-2.1?';

app.get('/', (req, res) => {
    res.sendFile('dist/index.html');
});

app.post('/api', async (req, res) => {
    console.log("POST request to /api", req.body);

    const inputUrl = req.body.url;
    const requestUrl = `${apiEndpoint}key=${apiKey}&url=${inputUrl}&lang=en`;

    try {
        const apiResponse = await fetch(requestUrl);
        const jsonData = await apiResponse.json();
        console.log("API Response: ", jsonData);
        res.send(jsonData);
    } catch (error) {
        console.error("Error during API call: ", error);
        res.status(500).send({ error: "Failed to fetch from the API" });
    }
});

app.listen(8080, () => {
    console.log('App listening on port 8080');
});
