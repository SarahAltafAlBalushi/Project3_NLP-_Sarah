// js files
import { validateUrl } from './js/UrlChecker';
import { form } from './js/formHandler'; 
import { detectName } from './js/nameChecker';


// sass files
import './styles/resets.scss'
import './styles/base.scss'
import './styles/footer.scss'
import './styles/form.scss'
import './styles/header.scss'

