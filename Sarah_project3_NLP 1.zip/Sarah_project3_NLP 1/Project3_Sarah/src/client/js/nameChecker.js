function detectName(inputText) {
    console.log("::: Running detectName :::", inputText);

    const captainsList = [
        "Picard",
        "Janeway",
        "Kirk",
        "Archer",
        "Georgiou"
    ];

    if (captainsList.includes(inputText)) {
        alert("Welcome, Captain!");
    }
}

export { detectName };
