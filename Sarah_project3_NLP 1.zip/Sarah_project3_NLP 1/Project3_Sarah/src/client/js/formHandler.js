import { validateUrl } from './UrlChecker';

const form = document.getElementById('urlForm');
form.addEventListener('submit', (event) => {
    event.preventDefault();

    const inputUrl = document.getElementById('name').value.trim();

    if (validateUrl(inputUrl)) {
        fetchServerData('/api', { url: inputUrl });
    } else {
        alert("Invalid URL. Please check and try again.");
    }
});

async function fetchServerData(apiPath, data) {
    try {
        const response = await fetch(apiPath, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });

        if (!response.ok) {
            console.error("Error response from server");
            return;
        }

        const result = await response.json();
        displayResults(result);
    } catch (error) {
        console.error("Failed to connect to the server:", error);
    }
}

function displayResults(result) {
    const elements = {
        polarity: "Polarity",
        agreement: "Agreement",
        subjectivity: "Subjectivity",
        confidence: "Confidence",
        irony: "Irony",
    };

    for (const [key, label] of Object.entries(elements)) {
        document.getElementById(key).innerHTML = `${label}: ${result[key] || "Not available"}`;
    }
}

export { form };







