module.exports = {
    setupFiles: ['<rootDir>/jest.setup.js'], // Ensures the setup file is loaded
    testEnvironment: 'jsdom', // Simulates a browser environment
  };