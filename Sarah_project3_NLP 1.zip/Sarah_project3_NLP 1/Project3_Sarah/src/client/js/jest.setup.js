import 'whatwg-fetch'; // Polyfill fetch for testing
