import { validateUrl } from "../src/client/js/UrlChecker";

// Test suite for the URL validation functionality
describe("Testing the URL validation functionality", () => {
    // Test to ensure the function is defined
    test("Should define the validateUrl() function", () => {
        expect(validateUrl).toBeDefined();
    });

    // Test the function with both valid and invalid URLs
    test("Should validate URLs correctly", () => {
        const validUrl = "https://example.com";
        const invalidUrl = "this-is-not-a-url";

        expect(validateUrl(validUrl)).toBe(true); // Valid URL should return true
        expect(validateUrl(invalidUrl)).toBe(false); // Invalid URL should return false
    });
});
