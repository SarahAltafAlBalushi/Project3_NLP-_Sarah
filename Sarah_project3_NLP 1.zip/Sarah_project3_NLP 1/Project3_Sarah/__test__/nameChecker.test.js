import { detectName } from "../src/client/js/nameChecker";

// Testing name validation functionality
describe("Testing the name validation process", () => {
    // Test to ensure the function is defined
    test("Should define the detectName() function", () => {
        expect(detectName).toBeDefined();
    });
});
