//import functions 
import { validateUrl } from './js/UrlChecker';
import { initializeFormHandler } from './js/formHandler';
import { detectName } from './js/nameChecker';

// Import styles
import './styles/resets.scss';
import './styles/base.scss';
import './styles/footer.scss';
import './styles/form.scss';
import './styles/header.scss';

// Initializing form handler after DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('urlForm');
    if (form) {
        initializeFormHandler(form);
    } else {
        console.error("Form with id 'urlForm' not found in the DOM.");
    }
});