import 'whatwg-fetch'; // Polyfill fetch for testing
import fetchMock from "jest-fetch-mock";
fetchMock.enableMocks();
