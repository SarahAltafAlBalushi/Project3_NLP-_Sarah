console.log("URL Checker loaded");

function validateUrl(userInput) {
    const pattern = /^(https?:\/\/)?(www\.)?[-a-zA-Z0-9@:%._+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_+.~#?&//=]*)$/;
    return pattern.test(userInput.trim());
}

export { validateUrl };