/**
 * @jest-environment jsdom
 */
import { initializeFormHandler } from "../src/client/js/formHandler";

// Ensure fetch is mocked
import fetchMock from "jest-fetch-mock";
fetchMock.enableMocks();

// Mock validateUrl
jest.mock("../src/client/js/UrlChecker", () => ({
    validateUrl: jest.fn(() => true), // Always return true for simplicity
}));

beforeEach(() => {
    // Set up the DOM structure needed for the test
    document.body.innerHTML = `
        <form id="urlForm">
            <input id="name" />
            <button type="submit">Submit</button>
        </form>
        <div id="polarity"></div>
        <div id="agreement"></div>
        <div id="confidence"></div>
    `;
    fetchMock.resetMocks(); // Reset fetch mocks before each test
});

test("form submission should call fetchServerData", async () => {
    const form = document.getElementById("urlForm");
    initializeFormHandler(form);

    // Mock fetch response
    fetchMock.mockResponseOnce(
        JSON.stringify({
            polarity: "Positive",
            agreement: "Agreement",
            confidence: "High",
        })
    );

    // Simulate user input and form submission
    document.getElementById("name").value = "https://example.com";
    form.dispatchEvent(new Event("submit"));

    // Wait for fetch to resolve
    await new Promise(process.nextTick);

    // Validate expectations
    expect(fetchMock).toHaveBeenCalledTimes(1); // Ensure fetch was called
    expect(fetchMock).toHaveBeenCalledWith("/api", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: "https://example.com" }),
    });
    expect(document.getElementById("polarity").innerHTML).toBe("Polarity: Positive");
    expect(document.getElementById("agreement").innerHTML).toBe("Agreement: Agreement");
    expect(document.getElementById("confidence").innerHTML).toBe("Confidence: High");
});
